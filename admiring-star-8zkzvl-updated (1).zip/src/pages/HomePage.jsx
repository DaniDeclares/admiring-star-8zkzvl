import React from "react";
import { Link } from "react-router-dom";

export default function HomePage() {
  const divisions = [
    {
      id: "business-solutions",
      title: "Business Solutions",
      tagline: "Launch. Organize. Grow.",
      badge: "GovOps & Admin",
      description: "PMO governance, administrative support, compliance frameworks, SOP manual development, and vendor readiness packets.",
      link: "/services/business-solutions"
    },
    {
      id: "creative-print",
      title: "Creative & Print Studio",
      tagline: "Design. Print. Brand.",
      badge: "ProductOps",
      description: "Custom heat-press apparel, sublimated tumblers, packaging labels, 9 SmartTap™ NFC Cards, and Smart Review Stands.",
      link: "/services/print-studio"
    },
    {
      id: "events-experiences",
      title: "Events & Experiences",
      tagline: "Plan. Produce. Celebrate.",
      badge: "EventOps",
      description: "On-site execution teams, vendor/speaker table coordination, event logistics, and direct wedding officiant services.",
      link: "/services/events"
    },
    {
      id: "property-hospitality",
      title: "Property & Hospitality",
      tagline: "Reset. Maintain. Support.",
      badge: "FieldOps",
      description: "Multi-family unit turnovers, deep cleaning, 2-hr digital HD photo logs, 24-48 hr SLAs, and /usr/bin/bash-cost resident concierge perks.",
      link: "/industries/real-estate"
    },
    {
      id: "concierge-operations",
      title: "Concierge & Operations",
      tagline: "Coordinate. Execute. Simplify.",
      badge: "DocOps & Courier",
      description: "Mobile Notary public, loan signings, living trusts, durable POAs, court filing couriers, and international apostilles.",
      link: "/services/concierge"
    },
    {
      id: "express-goods",
      title: "Express & Goods",
      tagline: "Supply. Deliver. Convenience.",
      badge: "Marketplace",
      description: "Curated snack combo packages (, , 0, 5), branded merchandise, and express mobile delivery.",
      link: "/shop"
    }
  ];

  const processSteps = [
    { step: "01", title: "Intake & Alignment", desc: "Submit requirements via universal intake or book directly." },
    { step: "02", title: "Scope & Terms", desc: "Receive transparent pricing, SLA timelines, and digital deposit terms." },
    { step: "03", title: "Field Deployment", desc: "Specialized units deploy using guided digital SOP checklists." },
    { step: "04", title: "Proof & Delivery", desc: "Review HD photo logs, digital receipts, and confirm completion." }
  ];

  return (
    <div className="dd-homepage-container" style={{ fontFamily: 'system-ui, -apple-system, sans-serif', color: '#1B0A0E', backgroundColor: '#FFFFFF' }}>
      
      {/* 1. HERO SECTION */}
      <section className="dd-hero" style={{
        backgroundColor: '#0F050A',
        color: '#F8F5F1',
        padding: '4.5rem 1.5rem 5.5rem',
        textAlign: 'center',
        borderBottom: '1px solid #2D1B28'
      }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div style={{
            display: 'inline-block',
            backgroundColor: '#2D1B28',
            color: '#C8B273',
            padding: '0.4rem 1rem',
            borderRadius: '20px',
            fontSize: '0.85rem',
            fontWeight: '700',
            letterSpacing: '0.05em',
            textTransform: 'uppercase',
            marginBottom: '1.25rem',
            border: '1px solid #C8B273'
          }}>
            Dani Declares LLC • Registered Execution Partner
          </div>

          <h1 style={{
            fontSize: 'clamp(2.5rem, 5vw, 4.2rem)',
            fontWeight: '800',
            lineHeight: '1.1',
            marginBottom: '1.25rem',
            color: '#F8F5F1'
          }}>
            We Handle the Execution.
          </h1>

          <p style={{
            fontSize: 'clamp(1.1rem, 2vw, 1.35rem)',
            color: '#D1C7BD',
            maxWidth: '820px',
            margin: '0 auto 2.25rem',
            lineHeight: '1.6'
          }}>
            From business launches and branded materials to property resets, concierge coordination, and everyday solutions—DANI DECLARES LLC delivers professional, multi-division execution when details matter.
          </p>

          <div style={{
            display: 'flex',
            gap: '1rem',
            justifyContent: 'center',
            flexWrap: 'wrap',
            marginBottom: '2.5rem'
          }}>
            <Link to="/book" style={{
              backgroundColor: '#C8B273',
              color: '#0F050A',
              padding: '0.9rem 2.25rem',
              borderRadius: '6px',
              fontWeight: '800',
              fontSize: '1.05rem',
              textDecoration: 'none'
            }}>
              Start a Project &rarr;
            </Link>

            <Link to="/services" style={{
              backgroundColor: 'transparent',
              color: '#F8F5F1',
              padding: '0.9rem 2.25rem',
              borderRadius: '6px',
              fontWeight: '700',
              fontSize: '1.05rem',
              textDecoration: 'none',
              border: '1px solid #C8B273'
            }}>
              Explore Services
            </Link>
          </div>

          {/* Credential Bar */}
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            gap: '1.5rem',
            flexWrap: 'wrap',
            fontSize: '0.85rem',
            color: '#9E8D7C',
            borderTop: '1px solid #2D1B28',
            paddingTop: '1.75rem'
          }}>
            <span>GA SOS Registered #25079444</span>
            <span>•</span>
            <span>SAM.gov Active (UEI: TD4TSG48LHN9 | CAGE: 17VV2)</span>
            <span>•</span>
            <span>Fully Insured (M+ Coverage)</span>
          </div>
        </div>
      </section>

      {/* 2. SIX STRATEGIC DIVISIONS */}
      <section style={{ backgroundColor: '#F8F5F1', padding: '5rem 1.5rem' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
            <h2 style={{ fontSize: '2.25rem', fontWeight: '800', marginBottom: '0.75rem', color: '#8B1E2E' }}>
              Six Strategic Execution Divisions
            </h2>
            <p style={{ fontSize: '1.1rem', color: '#5A4A52', maxWidth: '650px', margin: '0 auto' }}>
              Single-source accountability across business, property, creative, and operational workflows.
            </p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '1.75rem'
          }}>
            {divisions.map((div) => (
              <div key={div.id} style={{
                backgroundColor: '#FFFFFF',
                border: '1px solid #E2D9D0',
                borderRadius: '8px',
                padding: '2rem',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                boxShadow: '0 2px 8px rgba(0,0,0,0.03)'
              }}>
                <div>
                  <span style={{
                    fontSize: '0.75rem',
                    fontWeight: '700',
                    color: '#8B1E2E',
                    backgroundColor: '#F3ECE7',
                    padding: '0.25rem 0.6rem',
                    borderRadius: '4px',
                    textTransform: 'uppercase'
                  }}>
                    {div.badge}
                  </span>

                  <h3 style={{ fontSize: '1.4rem', fontWeight: '700', marginTop: '1rem', marginBottom: '0.25rem', color: '#1B0A0E' }}>
                    {div.title}
                  </h3>
                  <div style={{ fontSize: '0.95rem', fontWeight: '700', color: '#C8B273', marginBottom: '0.85rem' }}>
                    {div.tagline}
                  </div>
                  <p style={{ fontSize: '0.95rem', color: '#4A3B43', lineHeight: '1.5', marginBottom: '1.5rem' }}>
                    {div.description}
                  </p>
                </div>

                <Link to={div.link} style={{
                  color: '#8B1E2E',
                  fontWeight: '700',
                  textDecoration: 'none',
                  fontSize: '0.95rem',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.4rem'
                }}>
                  Explore Division &rarr;
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. TRUST & PROCESS SECTION */}
      <section style={{ backgroundColor: '#FFFFFF', padding: '5rem 1.5rem', borderTop: '1px solid #E2D9D0' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
            <h2 style={{ fontSize: '2.25rem', fontWeight: '800', color: '#8B1E2E', marginBottom: '0.75rem' }}>
              Built for Verified Field Reliability
            </h2>
            <p style={{ fontSize: '1.1rem', color: '#5A4A52', maxWidth: '700px', margin: '0 auto' }}>
              We operate with standardized SOPs, guaranteed SLAs, and visual proof of work for every job.
            </p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: '2rem',
            marginBottom: '4rem'
          }}>
            <div style={{ padding: '1.75rem', backgroundColor: '#F8F5F1', borderRadius: '8px', borderLeft: '4px solid #8B1E2E' }}>
              <h4 style={{ fontSize: '1.15rem', fontWeight: '700', marginBottom: '0.5rem', color: '#1B0A0E' }}>2-Hour Digital HD Photo Logs</h4>
              <p style={{ fontSize: '0.925rem', color: '#4A3B43', lineHeight: '1.5' }}>
                Field units capture before/after photos and digital inspection checklists delivered within 2 hours of completion.
              </p>
            </div>

            <div style={{ padding: '1.75rem', backgroundColor: '#F8F5F1', borderRadius: '8px', borderLeft: '4px solid #C8B273' }}>
              <h4 style={{ fontSize: '1.15rem', fontWeight: '700', marginBottom: '0.5rem', color: '#1B0A0E' }}>24–48 Hour SLA Guarantees</h4>
              <p style={{ fontSize: '0.925rem', color: '#4A3B43', lineHeight: '1.5' }}>
                Fast turnover timelines for property managers and rapid same-day response options for notary and court filings.
              </p>
            </div>

            <div style={{ padding: '1.75rem', backgroundColor: '#F8F5F1', borderRadius: '8px', borderLeft: '4px solid #8B1E2E' }}>
              <h4 style={{ fontSize: '1.15rem', fontWeight: '700', marginBottom: '0.5rem', color: '#1B0A0E' }}>Government & Corporate Ready</h4>
              <p style={{ fontSize: '0.925rem', color: '#4A3B43', lineHeight: '1.5' }}>
                SAM.gov active (CAGE: 17VV2) with W-9 and Certificate of Insurance (COI) ready for immediate vendor onboarding.
              </p>
            </div>
          </div>

          {/* 4-Step Process */}
          <div style={{ textAlign: 'center', marginTop: '2rem' }}>
            <h3 style={{ fontSize: '1.75rem', fontWeight: '800', marginBottom: '2.5rem', color: '#1B0A0E' }}>The 4-Step Execution Process</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.5rem' }}>
              {processSteps.map((p, i) => (
                <div key={i} style={{ textAlign: 'center', padding: '1rem', backgroundColor: '#FAF8F5', borderRadius: '8px', border: '1px solid #EAE3DF' }}>
                  <div style={{ fontSize: '2rem', fontWeight: '800', color: '#C8B273', marginBottom: '0.25rem' }}>{p.step}</div>
                  <h5 style={{ fontSize: '1.05rem', fontWeight: '700', marginBottom: '0.4rem', color: '#1B0A0E' }}>{p.title}</h5>
                  <p style={{ fontSize: '0.875rem', color: '#5A4A52', lineHeight: '1.4' }}>{p.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 4. REVENUE PATHS & FINAL CALL TO ACTION */}
      <section style={{ backgroundColor: '#0F050A', padding: '4.5rem 1.5rem', color: '#F8F5F1' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', textAlign: 'center' }}>
          <h2 style={{ fontSize: '2rem', fontWeight: '800', marginBottom: '2.5rem', color: '#F8F5F1' }}>
            How Would You Like to Connect?
          </h2>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem' }}>
            {/* Service Client */}
            <div style={{ backgroundColor: '#1F101A', padding: '2rem', borderRadius: '8px', border: '1px solid #3A202E' }}>
              <h3 style={{ fontSize: '1.3rem', fontWeight: '700', marginBottom: '0.5rem', color: '#C8B273' }}>
                Need Something Handled?
              </h3>
              <p style={{ fontSize: '0.925rem', color: '#D1C7BD', marginBottom: '1.5rem' }}>
                Book an appointment or submit a project request for notary, property resets, business support, or print orders.
              </p>
              <Link to="/book" style={{
                backgroundColor: '#C8B273', color: '#0F050A', padding: '0.75rem 1.5rem',
                borderRadius: '4px', fontWeight: '700', textDecoration: 'none', display: 'inline-block'
              }}>
                Book a Service &rarr;
              </Link>
            </div>

            {/* Product Customer */}
            <div style={{ backgroundColor: '#1F101A', padding: '2rem', borderRadius: '8px', border: '1px solid #3A202E' }}>
              <h3 style={{ fontSize: '1.3rem', fontWeight: '700', marginBottom: '0.5rem', color: '#C8B273' }}>
                Products & Merchandise?
              </h3>
              <p style={{ fontSize: '0.925rem', color: '#D1C7BD', marginBottom: '1.5rem' }}>
                Order SmartTap™ NFC cards, Smart Review Stands, custom apparel, or Express Goods snack combos.
              </p>
              <Link to="/shop" style={{
                backgroundColor: '#8B1E2E', color: '#F8F5F1', padding: '0.75rem 1.5rem',
                borderRadius: '4px', fontWeight: '700', textDecoration: 'none', display: 'inline-block'
              }}>
                Visit Marketplace &rarr;
              </Link>
            </div>

            {/* Contracting Partner */}
            <div style={{ backgroundColor: '#1F101A', padding: '2rem', borderRadius: '8px', border: '1px solid #3A202E' }}>
              <h3 style={{ fontSize: '1.3rem', fontWeight: '700', marginBottom: '0.5rem', color: '#C8B273' }}>
                Subcontracting & Teaming?
              </h3>
              <p style={{ fontSize: '0.925rem', color: '#D1C7BD', marginBottom: '1.5rem' }}>
                Access our SAM.gov capability statement, vendor packet, and municipal/corporate teaming details.
              </p>
              <Link to="/industries/government" style={{
                border: '1px solid #C8B273', color: '#F8F5F1', padding: '0.75rem 1.5rem',
                borderRadius: '4px', fontWeight: '700', textDecoration: 'none', display: 'inline-block'
              }}>
                GovCon Profile &rarr;
              </Link>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
