import React from "react";
import { Link } from "react-router-dom";

export default function ServicesPage() {
  const divisions = [
    {
      title: "Business Solutions",
      tagline: "Launch. Organize. Grow.",
      link: "/services/business-solutions",
      items: [
        "PMO Governance & Project Management Consulting",
        "SOP Manual Development & Operational Workflows",
        "Vendor Readiness Packets (W-9, COI, Capability Profile)",
        "Client Intake & Business System Infrastructure"
      ]
    },
    {
      title: "Creative & Print Studio",
      tagline: "Design. Print. Brand.",
      link: "/services/print-studio",
      items: [
        "Custom Heat-Press Apparel & Sublimated Tumblers",
        "Packaging Labels & Custom Marketing Merchandise",
        "9 SmartTap™ NFC Business Cards & Google Review Stands",
        "50% Deposit Pre-Order Custom Production System"
      ]
    },
    {
      title: "Events & Experiences",
      tagline: "Plan. Produce. Celebrate.",
      link: "/services/events",
      items: [
        "On-Site Event Setup & Logistics Execution Teams",
        "Vendor & Speaker Table Coordination",
        "Stand-Alone Wedding Officiant Services (9–49)",
        "Marriage License Filings & Rehearsal Coordination"
      ]
    },
    {
      title: "Property & Hospitality",
      tagline: "Reset. Maintain. Support.",
      link: "/industries/real-estate",
      items: [
        "Multi-Family Unit Turnovers & Move-In/Out Deep Cleans",
        "2-Hour Digital HD Photo Logs & Inspection Reports",
        "24–48 Hour Turnover SLA Guarantee",
        "/usr/bin/bash-Cost Resident Concierge Perks & Key Couriers"
      ]
    },
    {
      title: "Concierge & Operations",
      tagline: "Coordinate. Execute. Simplify.",
      link: "/services/concierge",
      items: [
        "Mobile Notary Visit (0 flat fee) & Loan Signings (50)",
        "I-9 Employment Verification (0) & FD-258 Fingerprinting (0–0)",
        "Expedited Apostille Assistance (75) & Court Document Couriers",
        "Notary + Financial Planning Session (35)"
      ]
    },
    {
      title: "Express & Goods",
      tagline: "Supply. Deliver. Convenience.",
      link: "/shop",
      items: [
        "Quick Snack Packs & After-School Boxes (, , 0, 5)",
        "Gamer Packs & Family Movie Night Snack Bundles",
        "Branded Merchandise & On-Demand Local Mobile Delivery",
        "Direct E-Commerce Order Fulfillment"
      ]
    }
  ];

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', color: '#1B0A0E', backgroundColor: '#F8F5F1', minHeight: '100vh' }}>
      <section style={{ backgroundColor: '#0F050A', color: '#F8F5F1', padding: '4rem 1.5rem', textAlign: 'center' }}>
        <div style={{ maxWidth: '900px', margin: '0 auto' }}>
          <h1 style={{ fontSize: '2.75rem', fontWeight: '800', marginBottom: '1rem', color: '#F8F5F1' }}>
            Universal Services Directory
          </h1>
          <p style={{ fontSize: '1.2rem', color: '#D1C7BD', lineHeight: '1.6' }}>
            Explore Dani Declares LLC's six core execution divisions. Single-source professional delivery across business, property, creative, and operational workflows.
          </p>
        </div>
      </section>

      <section style={{ padding: '4rem 1.5rem', maxWidth: '1200px', margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '2rem' }}>
          {divisions.map((div, i) => (
            <div key={i} style={{
              backgroundColor: '#FFFFFF',
              border: '1px solid #E2D9D0',
              borderRadius: '8px',
              padding: '2.25rem',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between'
            }}>
              <div>
                <h2 style={{ fontSize: '1.6rem', fontWeight: '800', color: '#8B1E2E', marginBottom: '0.25rem' }}>{div.title}</h2>
                <div style={{ fontSize: '0.95rem', fontWeight: '700', color: '#C8B273', marginBottom: '1.25rem' }}>{div.tagline}</div>
                <ul style={{ paddingLeft: '1.2rem', margin: '0 0 1.5rem', fontSize: '0.95rem', color: '#4A3B43', lineHeight: '1.6' }}>
                  {div.items.map((item, idx) => (
                    <li key={idx} style={{ marginBottom: '0.5rem' }}>{item}</li>
                  ))}
                </ul>
              </div>
              <Link to={div.link} style={{
                backgroundColor: '#8B1E2E', color: '#F8F5F1', padding: '0.75rem 1.25rem',
                borderRadius: '4px', fontWeight: '700', textDecoration: 'none', textAlign: 'center'
              }}>
                View Division Details &rarr;
              </Link>
            </div>
          ))}
        </div>

        <div style={{ textAlign: 'center', marginTop: '4rem', padding: '2.5rem', backgroundColor: '#FFFFFF', borderRadius: '8px', border: '1px solid #E2D9D0' }}>
          <h3 style={{ fontSize: '1.5rem', fontWeight: '800', color: '#1B0A0E', marginBottom: '0.5rem' }}>Need a Custom Execution Plan?</h3>
          <p style={{ color: '#5A4A52', marginBottom: '1.5rem' }}>Submit your project specifications to receive a transparent proposal and SLA timeline.</p>
          <Link to="/book" style={{
            backgroundColor: '#C8B273', color: '#0F050A', padding: '0.85rem 2rem',
            borderRadius: '4px', fontWeight: '800', textDecoration: 'none'
          }}>
            Submit Project Specifications &rarr;
          </Link>
        </div>
      </section>
    </div>
  );
}
